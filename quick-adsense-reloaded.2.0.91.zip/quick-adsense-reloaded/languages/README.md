#  Quick AdSense Reloaded I18n #

  To help translate, review, or improve a translation, write Rene Hermenau at info@mashshare.net


# Quick Start #

    In quick-adsense-reloaded/languages/ you find a file named quads.po

    - Open it with the free editor: http://poedit.net/

    - Translate the strings and save it. Poedit automatically creates the file quads.mo

    - Rename this to your language specific translation. E.g. for italy the file is called quads-it_IT.mo and put it into the folder /quick-adsense-reloaded/languages/

I really appreciate it if you like to send me the generated mo file. I will put it than into the official Quick AdSense Reloaded Plugin repository.

