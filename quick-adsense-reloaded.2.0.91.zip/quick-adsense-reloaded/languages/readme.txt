********************************************************

  Quick AdSense Reloaded I18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Quick AdSense Reloaded updates.
  
  Keep custom QUADS translations in /wp-content/languages/quads/
  
  You want to translate, help, or improve a translation?
  Write: info@mashshare.net

********************************************************
