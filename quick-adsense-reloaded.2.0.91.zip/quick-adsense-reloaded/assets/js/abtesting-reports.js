(function($){
    $(document).on( 'change', '#report_type' , function(){
        console.log('ok');
    } )
})