window.$quads_hooks = {
    test: '<input type="text" name="adb" value="ddddd">'
}
