<?php
function sakmpar_auto_menu() {
    add_menu_page('Sakmpar Auto', 'Sakmpar Auto', 'manage_options', 'sakmpar-auto', 'sakmpar_auto_settings_page');
}

add_action('admin_menu', 'sakmpar_auto_menu');

function sakmpar_auto_settings_page() {
    ?>
    <div class="wrap">
        <h1>Sakmpar Auto Plugin</h1>
        <form method="post">
            <input type="text" name="website_url" placeholder="Enter Website URL" style="width: 100%; padding: 8px;" />
            <input type="submit" name="sakmpar_submit" value="Optimize" class="button button-primary" />
        </form>
        <?php
        if (isset($_POST['sakmpar_submit']) && !empty($_POST['website_url'])) {
            $url = esc_url_raw($_POST['website_url']);
            echo "<p>Optimizing: $url</p>";
            do_action('sakmpar_auto_optimize', $url);
        }
        ?>
    </div>
    <?php
}
?>
