<?php
/*
Plugin Name: Sakmpar Auto
Plugin URI: https://www.sakmpar.co.in
Description: Automatically analyzes and improves website content, SEO, and AdSense compatibility from any URL.
Version: 1.0
Author: Sunil Kumar Sahu
Author URI: https://www.sakmpar.co.in
License: GPL2
*/

defined('ABSPATH') or die('No script kiddies please!');

require_once plugin_dir_path(__FILE__) . 'includes/admin-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/auto-optimizer.php';
?>
