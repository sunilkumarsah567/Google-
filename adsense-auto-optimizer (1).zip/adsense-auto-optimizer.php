<?php
/**
 * Plugin Name: AdSense Auto Optimizer
 * Description: Automatically optimizes posts for Google AdSense on activation.
 * Version: 1.0
 * Author: ChatGPT Custom
 */

register_activation_hook(__FILE__, 'adsense_auto_optimizer_run');

function adsense_auto_optimizer_run() {
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1
    );
    $posts = get_posts($args);
    foreach ($posts as $post) {
        $content = $post->post_content;

        // Insert AdSense code after first paragraph
        $adsense_code = '<div class="adsense-ad">[Your AdSense Code Here]</div>';
        $paragraphs = explode('</p>', $content);
        if (count($paragraphs) > 1) {
            $paragraphs[1] .= $adsense_code;
        }
        $new_content = implode('</p>', $paragraphs);

        // Update post with new content
        wp_update_post(array(
            'ID' => $post->ID,
            'post_content' => $new_content
        ));
    }
}

add_action('admin_menu', function () {
    add_menu_page('AdSense Optimizer', 'AdSense Optimizer', 'manage_options', 'adsense-optimizer', 'adsense_optimizer_admin');
});

function adsense_optimizer_admin() {
    echo '<div class="wrap"><h1>AdSense Optimization Done</h1><p>All posts have been optimized for AdSense.</p></div>';
}
?>
