<?php
/*
Plugin Name: Auto Backlinker Pro
Plugin URI: http://wikilediablogs.liveblog365.com
Description: Automatically pings your WordPress site URLs to major ping services for backlinks and indexing, with logs.
Version: 1.1
Author: WikiLedia Team
*/

add_action('publish_post', 'ab_auto_ping_services');
add_action('publish_page', 'ab_auto_ping_services');

function ab_auto_ping_services($post_ID) {
    $ping_urls = array(
        "http://ping.feedburner.com",
        "http://ping.blogs.yandex.ru/RPC2",
        "http://rpc.pingomatic.com/",
        "http://blogsearch.google.com/ping/RPC2",
        "http://www.bing.com/ping?sitemap=",
        "http://www.feedlisting.com/",
        "http://blog.goo.ne.jp/XMLRPC",
        "http://ping.myblog.jp"
    );

    $post_url = get_permalink($post_ID);
    $log = "Post URL: " . $post_url . "\n";

    foreach ($ping_urls as $ping_url) {
        $target_url = (strpos($ping_url, 'sitemap') !== false) ? $ping_url . get_site_url() . '/sitemap.xml' : $ping_url;

        $response = wp_remote_post($target_url, array(
            'body' => array('url' => $post_url),
            'timeout' => 10,
            'headers' => array('Content-Type' => 'application/x-www-form-urlencoded')
        ));

        $log .= "Pinged: " . $target_url . " | Status: " . wp_remote_retrieve_response_code($response) . "\n";
    }

    $log_dir = WP_CONTENT_DIR . '/ab-backlink-logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_file = $log_dir . '/log-' . date("Y-m-d") . '.txt';
    file_put_contents($log_file, date("H:i:s") . " - " . $log . "\n", FILE_APPEND);

    return $post_ID;
}

add_action('admin_menu', 'ab_backlink_log_menu');
function ab_backlink_log_menu() {
    add_menu_page('Backlink Logs', 'Backlink Logs', 'manage_options', 'ab-backlink-logs', 'ab_show_logs');
}

function ab_show_logs() {
    echo "<div class='wrap'><h1>Backlink Logs</h1>";
    $log_dir = WP_CONTENT_DIR . '/ab-backlink-logs';
    if (file_exists($log_dir)) {
        $files = array_diff(scandir($log_dir), array('.', '..'));
        foreach ($files as $file) {
            echo "<h3>$file</h3><textarea style='width:100%;height:200px;'>";
            echo file_get_contents($log_dir . '/' . $file);
            echo "</textarea><hr>";
        }
    } else {
        echo "<p>No logs available.</p>";
    }
    echo "</div>";
}
?>