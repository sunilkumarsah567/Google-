import { storage } from "../storage";
import { keywordFetcher } from "../utils/keyword-fetcher";
import { rssParser } from "../utils/rss-parser";

export interface BlogPostData {
  title: string;
  content: string;
  excerpt: string;
  keywords: string[];
  category: string;
}

export class BlogGenerator {
  async generateBlogPost(websiteId: number): Promise<BlogPostData> {
    try {
      const config = await storage.getConfiguration(websiteId);
      const category = config?.siteCategory || "technology";
      const targetKeywords = config?.targetKeywords || [];

      // Get trending topics and keywords
      const [trendingTopics, trendingKeywords] = await Promise.all([
        keywordFetcher.getTrendingTopics(category),
        keywordFetcher.getTrendingKeywords(category, 10)
      ]);

      // Get latest news for inspiration
      const newsItems = await rssParser.getNewsFromMultipleSources(category);

      // Select a topic and generate content
      const selectedTopic = trendingTopics[0] || {
        title: `Latest Trends in ${category.charAt(0).toUpperCase() + category.slice(1)}`,
        keywords: targetKeywords.slice(0, 3),
        category,
        relevanceScore: 80
      };

      const blogPost = await this.createBlogContent(selectedTopic, trendingKeywords, newsItems.slice(0, 3));

      await storage.createActivityLog({
        websiteId,
        action: "blog_post_generated",
        description: `Generated blog post: "${blogPost.title}"`,
        type: "success",
        metadata: { keywords: blogPost.keywords, category: blogPost.category }
      });

      return blogPost;
    } catch (error) {
      await storage.createActivityLog({
        websiteId,
        action: "blog_generation_failed",
        description: `Failed to generate blog post: ${error}`,
        type: "error",
        metadata: null
      });
      throw error;
    }
  }

  private async createBlogContent(topic: any, keywords: any[], newsItems: any[]): Promise<BlogPostData> {
    const primaryKeywords = keywords.slice(0, 5).map(k => k.keyword);
    const title = this.generateTitle(topic, primaryKeywords);
    const content = this.generateContent(topic, primaryKeywords, newsItems);
    const excerpt = this.generateExcerpt(content);

    return {
      title,
      content,
      excerpt,
      keywords: primaryKeywords,
      category: topic.category
    };
  }

  private generateTitle(topic: any, keywords: string[]): string {
    const titleTemplates = [
      `The Ultimate Guide to ${keywords[0]} in 2024`,
      `How ${keywords[0]} is Revolutionizing ${topic.category}`,
      `Top 10 ${keywords[0]} Trends You Need to Know`,
      `Mastering ${keywords[0]}: A Complete Analysis`,
      `The Future of ${keywords[0]}: What Experts Predict`,
      `${keywords[0]} Best Practices for Modern Businesses`,
      `Understanding ${keywords[0]}: A Comprehensive Overview`,
      `${keywords[0]} Innovations That Are Changing Everything`
    ];

    const randomTemplate = titleTemplates[Math.floor(Math.random() * titleTemplates.length)];
    return randomTemplate;
  }

  private generateContent(topic: any, keywords: string[], newsItems: any[]): string {
    const sections = [
      this.generateIntroduction(keywords[0], topic.category),
      this.generateMainContent(keywords, newsItems),
      this.generateTechnicalSection(keywords),
      this.generatePracticalTips(keywords[0]),
      this.generateFutureOutlook(keywords[0], topic.category),
      this.generateConclusion(keywords[0])
    ];

    return sections.join('\n\n');
  }

  private generateIntroduction(primaryKeyword: string, category: string): string {
    return `<h2>Introduction</h2>

<p>In today's rapidly evolving digital landscape, <strong>${primaryKeyword}</strong> has emerged as a cornerstone of modern ${category}. This comprehensive guide explores the latest developments, trends, and practical applications that are shaping the industry.</p>

<p>Whether you're a professional looking to stay ahead of the curve or a business seeking to leverage cutting-edge solutions, understanding ${primaryKeyword} is essential for success in the competitive marketplace.</p>`;
  }

  private generateMainContent(keywords: string[], newsItems: any[]): string {
    const sections = keywords.slice(0, 3).map((keyword, index) => {
      const newsContext = newsItems[index] ? this.extractInsights(newsItems[index]) : "";
      
      return `<h2>${keyword.charAt(0).toUpperCase() + keyword.slice(1)}: Key Insights</h2>

<p>Recent developments in ${keyword} have shown remarkable progress across multiple sectors. Industry experts emphasize the importance of adopting innovative approaches to maximize efficiency and drive growth.</p>

${newsContext}

<p>Organizations implementing ${keyword} strategies report significant improvements in operational efficiency, customer satisfaction, and overall business performance. The key lies in understanding the fundamental principles and applying them strategically.</p>`;
    });

    return sections.join('\n\n');
  }

  private generateTechnicalSection(keywords: string[]): string {
    return `<h2>Technical Implementation and Best Practices</h2>

<p>Implementing ${keywords[0]} effectively requires a systematic approach that combines technical expertise with strategic planning. Here are the essential components for success:</p>

<ul>
<li><strong>Strategic Planning:</strong> Develop a comprehensive roadmap that aligns with your business objectives and market requirements.</li>
<li><strong>Technology Integration:</strong> Ensure seamless integration with existing systems and infrastructure for optimal performance.</li>
<li><strong>Performance Monitoring:</strong> Establish robust monitoring mechanisms to track progress and identify optimization opportunities.</li>
<li><strong>Continuous Improvement:</strong> Implement feedback loops and iterative processes to maintain competitive advantage.</li>
</ul>

<p>Success depends on careful attention to detail and commitment to following industry best practices throughout the implementation process.</p>`;
  }

  private generatePracticalTips(primaryKeyword: string): string {
    return `<h2>Practical Tips for Implementation</h2>

<p>To maximize the benefits of ${primaryKeyword}, consider these proven strategies:</p>

<ol>
<li><strong>Start Small:</strong> Begin with pilot projects to test approaches and gather valuable insights before scaling.</li>
<li><strong>Focus on Quality:</strong> Prioritize high-quality implementation over rapid deployment to ensure long-term success.</li>
<li><strong>Invest in Training:</strong> Ensure your team has the necessary skills and knowledge to leverage ${primaryKeyword} effectively.</li>
<li><strong>Monitor Performance:</strong> Regularly assess results and adjust strategies based on data-driven insights.</li>
<li><strong>Stay Updated:</strong> Keep abreast of the latest developments and emerging trends in the field.</li>
</ol>

<p>These actionable steps provide a solid foundation for achieving measurable results and maintaining competitive advantage in your industry.</p>`;
  }

  private generateFutureOutlook(primaryKeyword: string, category: string): string {
    return `<h2>Future Outlook and Emerging Trends</h2>

<p>The future of ${primaryKeyword} in ${category} looks promising, with several exciting developments on the horizon. Industry analysts predict continued growth and innovation driven by technological advancement and changing market demands.</p>

<p>Key trends to watch include:</p>

<ul>
<li>Increased automation and artificial intelligence integration</li>
<li>Enhanced focus on sustainability and environmental responsibility</li>
<li>Greater emphasis on personalization and user experience</li>
<li>Expansion into new markets and application areas</li>
</ul>

<p>Organizations that prepare for these changes today will be best positioned to capitalize on future opportunities and maintain their competitive edge.</p>`;
  }

  private generateConclusion(primaryKeyword: string): string {
    return `<h2>Conclusion</h2>

<p>${primaryKeyword} represents a significant opportunity for organizations seeking to enhance their capabilities and drive sustainable growth. By understanding the fundamentals, implementing best practices, and staying informed about emerging trends, businesses can position themselves for long-term success.</p>

<p>The key is to approach implementation strategically, with careful planning and commitment to continuous improvement. As the industry continues to evolve, those who embrace innovation and adapt to changing conditions will thrive in the competitive marketplace.</p>

<p>For more insights and updates on ${primaryKeyword} and related topics, stay connected with our blog and follow industry developments closely.</p>`;
  }

  private extractInsights(newsItem: any): string {
    if (!newsItem || !newsItem.description) return "";
    
    // Extract key points from news item
    const description = newsItem.description.replace(/<[^>]*>/g, '').substring(0, 200);
    
    return `<p><em>Recent industry reports indicate that ${description}... This development highlights the growing importance of staying current with market trends and technological innovations.</em></p>`;
  }

  private generateExcerpt(content: string): string {
    // Extract first paragraph as excerpt
    const firstParagraph = content.match(/<p>(.*?)<\/p>/);
    if (firstParagraph) {
      return firstParagraph[1].replace(/<[^>]*>/g, '').substring(0, 150) + '...';
    }
    
    return "Explore the latest insights and trends in this comprehensive analysis of industry developments and best practices.";
  }

  async scheduleNextPost(websiteId: number): Promise<Date> {
    const config = await storage.getConfiguration(websiteId);
    const frequency = config?.postFrequency || "1h";
    
    const intervals: Record<string, number> = {
      "1h": 60 * 60 * 1000,
      "2h": 2 * 60 * 60 * 1000,
      "6h": 6 * 60 * 60 * 1000,
      "24h": 24 * 60 * 60 * 1000
    };

    const interval = intervals[frequency] || intervals["1h"];
    return new Date(Date.now() + interval);
  }
}

export const blogGenerator = new BlogGenerator();
