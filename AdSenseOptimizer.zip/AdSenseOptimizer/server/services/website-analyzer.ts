import * as cheerio from "cheerio";
import { storage } from "../storage";
import { ActivityLog } from "@shared/schema";

export interface AnalysisResult {
  seoScore: number;
  speedScore: number;
  mobileScore: number;
  adsenseReady: number;
  issues: AnalysisIssue[];
  recommendations: string[];
}

export interface AnalysisIssue {
  type: "seo" | "speed" | "mobile" | "adsense";
  severity: "high" | "medium" | "low";
  title: string;
  description: string;
  fixable: boolean;
}

export class WebsiteAnalyzer {
  async analyzeWebsite(url: string, websiteId: number): Promise<AnalysisResult> {
    try {
      await this.logActivity(websiteId, "analysis_started", "Website analysis initiated", "info");

      // Fetch the website
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const html = await response.text();
      const $ = cheerio.load(html);

      // Perform various analyses
      const seoAnalysis = await this.analyzeSEO($, url);
      const speedAnalysis = await this.analyzeSpeed(html, url);
      const mobileAnalysis = await this.analyzeMobile($);
      const adsenseAnalysis = await this.analyzeAdSenseReadiness($, html);

      const issues: AnalysisIssue[] = [
        ...seoAnalysis.issues,
        ...speedAnalysis.issues,
        ...mobileAnalysis.issues,
        ...adsenseAnalysis.issues
      ];

      const result: AnalysisResult = {
        seoScore: seoAnalysis.score,
        speedScore: speedAnalysis.score,
        mobileScore: mobileAnalysis.score,
        adsenseReady: adsenseAnalysis.score,
        issues,
        recommendations: this.generateRecommendations(issues)
      };

      await this.logActivity(websiteId, "analysis_completed", 
        `Analysis completed - SEO: ${result.seoScore}%, Speed: ${result.speedScore}%, Mobile: ${result.mobileScore}%, AdSense: ${result.adsenseReady}%`, 
        "success");

      return result;
    } catch (error) {
      await this.logActivity(websiteId, "analysis_failed", `Analysis failed: ${error}`, "error");
      throw error;
    }
  }

  private async analyzeSEO($: cheerio.CheerioAPI, url: string) {
    const issues: AnalysisIssue[] = [];
    let score = 100;

    // Title tag analysis
    const title = $('title').text();
    if (!title) {
      issues.push({
        type: "seo",
        severity: "high",
        title: "Missing Title Tag",
        description: "The page is missing a title tag, which is crucial for SEO",
        fixable: true
      });
      score -= 20;
    } else if (title.length < 30 || title.length > 60) {
      issues.push({
        type: "seo",
        severity: "medium",
        title: "Title Tag Length",
        description: "Title tag should be between 30-60 characters",
        fixable: true
      });
      score -= 10;
    }

    // Meta description analysis
    const metaDesc = $('meta[name="description"]').attr('content');
    if (!metaDesc) {
      issues.push({
        type: "seo",
        severity: "high",
        title: "Missing Meta Description",
        description: "The page is missing a meta description",
        fixable: true
      });
      score -= 15;
    } else if (metaDesc.length < 120 || metaDesc.length > 160) {
      issues.push({
        type: "seo",
        severity: "medium",
        title: "Meta Description Length",
        description: "Meta description should be between 120-160 characters",
        fixable: true
      });
      score -= 8;
    }

    // Heading structure analysis
    const h1Count = $('h1').length;
    if (h1Count === 0) {
      issues.push({
        type: "seo",
        severity: "high",
        title: "Missing H1 Tag",
        description: "The page should have exactly one H1 tag",
        fixable: true
      });
      score -= 15;
    } else if (h1Count > 1) {
      issues.push({
        type: "seo",
        severity: "medium",
        title: "Multiple H1 Tags",
        description: "The page should have only one H1 tag",
        fixable: true
      });
      score -= 10;
    }

    // Images without alt text
    const imagesWithoutAlt = $('img:not([alt])').length;
    if (imagesWithoutAlt > 0) {
      issues.push({
        type: "seo",
        severity: "medium",
        title: "Images Missing Alt Text",
        description: `${imagesWithoutAlt} images are missing alt text`,
        fixable: true
      });
      score -= Math.min(20, imagesWithoutAlt * 2);
    }

    // Internal links analysis
    const internalLinks = $('a[href^="/"], a[href*="' + new URL(url).hostname + '"]').length;
    if (internalLinks < 3) {
      issues.push({
        type: "seo",
        severity: "low",
        title: "Few Internal Links",
        description: "Consider adding more internal links to improve site structure",
        fixable: true
      });
      score -= 5;
    }

    return { score: Math.max(0, score), issues };
  }

  private async analyzeSpeed(html: string, url: string) {
    const issues: AnalysisIssue[] = [];
    let score = 100;

    // HTML size analysis
    const htmlSize = Buffer.byteLength(html, 'utf8');
    if (htmlSize > 100000) { // 100KB
      issues.push({
        type: "speed",
        severity: "medium",
        title: "Large HTML Size",
        description: "HTML size is larger than recommended (100KB)",
        fixable: true
      });
      score -= 15;
    }

    // CSS and JS analysis
    const $ = cheerio.load(html);
    const cssLinks = $('link[rel="stylesheet"]').length;
    const jsScripts = $('script[src]').length;

    if (cssLinks > 5) {
      issues.push({
        type: "speed",
        severity: "medium",
        title: "Too Many CSS Files",
        description: "Consider combining CSS files to reduce HTTP requests",
        fixable: true
      });
      score -= 10;
    }

    if (jsScripts > 5) {
      issues.push({
        type: "speed",
        severity: "medium",
        title: "Too Many JavaScript Files",
        description: "Consider combining JavaScript files to reduce HTTP requests",
        fixable: true
      });
      score -= 10;
    }

    // Image optimization check
    const images = $('img');
    let largeImages = 0;
    images.each((_, img) => {
      const src = $(img).attr('src');
      if (src && !src.includes('.webp') && !src.includes('optimized')) {
        largeImages++;
      }
    });

    if (largeImages > 0) {
      issues.push({
        type: "speed",
        severity: "medium",
        title: "Unoptimized Images",
        description: `${largeImages} images could be optimized for better performance`,
        fixable: true
      });
      score -= Math.min(20, largeImages * 3);
    }

    // Minification check
    const hasMinifiedCSS = html.includes('.min.css');
    const hasMinifiedJS = html.includes('.min.js');

    if (!hasMinifiedCSS && cssLinks > 0) {
      issues.push({
        type: "speed",
        severity: "low",
        title: "CSS Not Minified",
        description: "CSS files should be minified for better performance",
        fixable: true
      });
      score -= 5;
    }

    if (!hasMinifiedJS && jsScripts > 0) {
      issues.push({
        type: "speed",
        severity: "low",
        title: "JavaScript Not Minified",
        description: "JavaScript files should be minified for better performance",
        fixable: true
      });
      score -= 5;
    }

    return { score: Math.max(0, score), issues };
  }

  private async analyzeMobile($: cheerio.CheerioAPI) {
    const issues: AnalysisIssue[] = [];
    let score = 100;

    // Viewport meta tag
    const viewport = $('meta[name="viewport"]').attr('content');
    if (!viewport) {
      issues.push({
        type: "mobile",
        severity: "high",
        title: "Missing Viewport Meta Tag",
        description: "Viewport meta tag is required for mobile responsiveness",
        fixable: true
      });
      score -= 30;
    } else if (!viewport.includes('width=device-width')) {
      issues.push({
        type: "mobile",
        severity: "medium",
        title: "Incorrect Viewport Configuration",
        description: "Viewport should include 'width=device-width'",
        fixable: true
      });
      score -= 15;
    }

    // Responsive CSS check
    const hasMediaQueries = $('style').text().includes('@media') || 
                           $('link[rel="stylesheet"]').length > 0; // Assume external CSS might have media queries

    if (!hasMediaQueries) {
      issues.push({
        type: "mobile",
        severity: "medium",
        title: "No Responsive CSS Detected",
        description: "Website should use CSS media queries for responsive design",
        fixable: true
      });
      score -= 20;
    }

    // Fixed width elements
    const hasFixedWidths = $('*[style*="width:"]').length > 0;
    if (hasFixedWidths) {
      issues.push({
        type: "mobile",
        severity: "low",
        title: "Fixed Width Elements",
        description: "Avoid using fixed widths for better mobile experience",
        fixable: true
      });
      score -= 10;
    }

    // Touch target size (buttons, links)
    const smallButtons = $('button, input[type="button"], input[type="submit"]').length;
    if (smallButtons > 0) {
      // This is a basic check - in reality, we'd need to measure actual sizes
      issues.push({
        type: "mobile",
        severity: "low",
        title: "Touch Target Size",
        description: "Ensure buttons and links are large enough for touch interaction (44px minimum)",
        fixable: true
      });
      score -= 5;
    }

    return { score: Math.max(0, score), issues };
  }

  private async analyzeAdSenseReadiness($: cheerio.CheerioAPI, html: string) {
    const issues: AnalysisIssue[] = [];
    let score = 100;

    // Content quality check
    const textContent = $.text().replace(/\s+/g, ' ').trim();
    const wordCount = textContent.split(' ').length;

    if (wordCount < 300) {
      issues.push({
        type: "adsense",
        severity: "high",
        title: "Insufficient Content",
        description: "Page needs at least 300 words of quality content for AdSense approval",
        fixable: true
      });
      score -= 40;
    }

    // Required pages check (these would need to be detected or assumed missing)
    const requiredPages = ['privacy', 'terms', 'about', 'contact'];
    const foundPages = requiredPages.filter(page => 
      $(`a[href*="${page}"]`).length > 0 || html.toLowerCase().includes(page)
    );

    if (foundPages.length < requiredPages.length) {
      issues.push({
        type: "adsense",
        severity: "high",
        title: "Missing Required Pages",
        description: "AdSense requires Privacy Policy, Terms of Service, About, and Contact pages",
        fixable: true
      });
      score -= 30;
    }

    // Navigation check
    const navElements = $('nav, .nav, .navigation, .menu').length;
    const headerLinks = $('header a, .header a').length;
    
    if (navElements === 0 && headerLinks < 3) {
      issues.push({
        type: "adsense",
        severity: "medium",
        title: "Poor Site Navigation",
        description: "Website needs clear navigation structure for AdSense approval",
        fixable: true
      });
      score -= 20;
    }

    // Copyright and footer check
    const footer = $('footer, .footer').text().toLowerCase();
    const hasCopyright = footer.includes('copyright') || footer.includes('©') || html.includes('©');
    
    if (!hasCopyright) {
      issues.push({
        type: "adsense",
        severity: "low",
        title: "Missing Copyright Notice",
        description: "Add copyright notice in footer for better credibility",
        fixable: true
      });
      score -= 10;
    }

    // Ad placement potential check
    const contentAreas = $('main, .main, .content, article').length;
    if (contentAreas === 0) {
      issues.push({
        type: "adsense",
        severity: "medium",
        title: "No Clear Content Areas",
        description: "Website needs clearly defined content areas for optimal ad placement",
        fixable: true
      });
      score -= 15;
    }

    return { score: Math.max(0, score), issues };
  }

  private generateRecommendations(issues: AnalysisIssue[]): string[] {
    const recommendations: string[] = [];
    
    // Group issues by type and priority
    const highPriorityIssues = issues.filter(issue => issue.severity === "high");
    const seoIssues = issues.filter(issue => issue.type === "seo");
    const speedIssues = issues.filter(issue => issue.type === "speed");
    const mobileIssues = issues.filter(issue => issue.type === "mobile");
    const adsenseIssues = issues.filter(issue => issue.type === "adsense");

    if (highPriorityIssues.length > 0) {
      recommendations.push("🔴 Start by fixing high-priority issues first for maximum impact");
    }

    if (seoIssues.length > 0) {
      recommendations.push("🔍 Improve SEO by adding proper title tags, meta descriptions, and heading structure");
    }

    if (speedIssues.length > 0) {
      recommendations.push("⚡ Optimize website speed by compressing images and minifying CSS/JS files");
    }

    if (mobileIssues.length > 0) {
      recommendations.push("📱 Ensure mobile responsiveness with proper viewport settings and flexible layouts");
    }

    if (adsenseIssues.length > 0) {
      recommendations.push("💰 Create required pages (Privacy Policy, Terms, About, Contact) for AdSense approval");
    }

    if (recommendations.length === 0) {
      recommendations.push("✅ Your website is in good shape! Consider regular monitoring and content updates");
    }

    return recommendations;
  }

  private async logActivity(websiteId: number, action: string, description: string, type: "success" | "warning" | "error" | "info") {
    try {
      await storage.createActivityLog({
        websiteId,
        action,
        description,
        type,
        metadata: null
      });
    } catch (error) {
      console.error("Failed to log activity:", error);
    }
  }
}

export const websiteAnalyzer = new WebsiteAnalyzer();
