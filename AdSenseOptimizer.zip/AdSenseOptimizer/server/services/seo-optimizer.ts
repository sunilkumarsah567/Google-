import * as cheerio from "cheerio";
import { storage } from "../storage";
import { keywordFetcher } from "../utils/keyword-fetcher";

export interface OptimizationResult {
  success: boolean;
  changes: string[];
  optimizedHtml?: string;
  error?: string;
}

export class SEOOptimizer {
  async optimizeWebsite(websiteId: number, originalHtml: string, targetKeywords: string[] = []): Promise<OptimizationResult> {
    try {
      const $ = cheerio.load(originalHtml);
      const changes: string[] = [];

      // Get or generate keywords
      const keywords = targetKeywords.length > 0 ? targetKeywords : await this.generateKeywords(websiteId);

      // Optimize title tag
      await this.optimizeTitle($, keywords, changes);

      // Optimize meta description
      await this.optimizeMetaDescription($, keywords, changes);

      // Optimize headings
      await this.optimizeHeadings($, keywords, changes);

      // Optimize images
      await this.optimizeImages($, changes);

      // Add structured data
      await this.addStructuredData($, changes);

      // Add canonical URL
      await this.addCanonicalUrl($, changes);

      // Optimize internal linking
      await this.optimizeInternalLinking($, changes);

      // Add Open Graph tags
      await this.addOpenGraphTags($, changes);

      const optimizedHtml = $.html();

      await this.logOptimization(websiteId, changes);

      return {
        success: true,
        changes,
        optimizedHtml
      };
    } catch (error) {
      await storage.createActivityLog({
        websiteId,
        action: "seo_optimization_failed",
        description: `SEO optimization failed: ${error}`,
        type: "error",
        metadata: null
      });

      return {
        success: false,
        changes: [],
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }

  private async generateKeywords(websiteId: number): Promise<string[]> {
    try {
      const config = await storage.getConfiguration(websiteId);
      const category = config?.siteCategory || "technology";
      
      const keywordData = await keywordFetcher.getTrendingKeywords(category, 10);
      return keywordData.map(k => k.keyword);
    } catch (error) {
      console.error("Error generating keywords:", error);
      return ["technology", "innovation", "digital", "online", "modern"];
    }
  }

  private async optimizeTitle($: cheerio.CheerioAPI, keywords: string[], changes: string[]) {
    const existingTitle = $('title').text();
    
    if (!existingTitle || existingTitle.length < 30) {
      const primaryKeyword = keywords[0] || "Professional Services";
      const newTitle = existingTitle 
        ? `${existingTitle} - ${primaryKeyword} | Professional Website`
        : `${primaryKeyword} - Professional Services | High Quality Solutions`;
      
      if ($('title').length === 0) {
        $('head').append(`<title>${newTitle}</title>`);
      } else {
        $('title').text(newTitle);
      }
      
      changes.push(`Updated title tag: "${newTitle}"`);
    }
  }

  private async optimizeMetaDescription($: cheerio.CheerioAPI, keywords: string[], changes: string[]) {
    const existingMeta = $('meta[name="description"]').attr('content');
    
    if (!existingMeta || existingMeta.length < 120) {
      const keywordString = keywords.slice(0, 3).join(', ');
      const newDescription = `Discover professional ${keywordString} services. Expert solutions for modern businesses with cutting-edge technology and innovative approaches. Get started today!`;
      
      if ($('meta[name="description"]').length === 0) {
        $('head').append(`<meta name="description" content="${newDescription}">`);
      } else {
        $('meta[name="description"]').attr('content', newDescription);
      }
      
      changes.push(`Added/updated meta description with target keywords`);
    }
  }

  private async optimizeHeadings($: cheerio.CheerioAPI, keywords: string[], changes: string[]) {
    // Ensure proper H1 tag
    const h1Count = $('h1').length;
    
    if (h1Count === 0) {
      const mainKeyword = keywords[0] || "Professional Services";
      const h1Text = `Expert ${mainKeyword} Solutions`;
      
      // Try to find main content area and add H1
      const mainContent = $('main, .main, .content, body').first();
      mainContent.prepend(`<h1>${h1Text}</h1>`);
      
      changes.push(`Added H1 tag: "${h1Text}"`);
    } else if (h1Count > 1) {
      // Convert extra H1s to H2s
      $('h1').slice(1).each((_, el) => {
        const text = $(el).text();
        $(el).replaceWith(`<h2>${text}</h2>`);
      });
      
      changes.push(`Converted ${h1Count - 1} extra H1 tags to H2 tags`);
    }

    // Optimize existing headings with keywords
    $('h2, h3').each((_, el) => {
      const text = $(el).text();
      if (text.length > 5 && !keywords.some(keyword => 
        text.toLowerCase().includes(keyword.toLowerCase())
      )) {
        // Only modify if it doesn't already contain keywords
        const relevantKeyword = keywords[Math.floor(Math.random() * Math.min(3, keywords.length))];
        // Don't modify if text is too short or already optimized
        if (text.length > 20 && Math.random() > 0.7) {
          $(el).text(`${text} - ${relevantKeyword}`);
          changes.push(`Enhanced heading with keyword: "${text}"`);
        }
      }
    });
  }

  private async optimizeImages($: cheerio.CheerioAPI, changes: string[]) {
    let optimizedCount = 0;
    
    $('img').each((_, img) => {
      const $img = $(img);
      const alt = $img.attr('alt');
      const src = $img.attr('src');
      
      if (!alt && src) {
        // Generate meaningful alt text based on src or context
        const filename = src.split('/').pop()?.split('.')[0] || 'image';
        const altText = filename.replace(/[-_]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        
        $img.attr('alt', altText);
        optimizedCount++;
      }
      
      // Add loading attribute for performance
      if (!$img.attr('loading')) {
        $img.attr('loading', 'lazy');
      }
    });
    
    if (optimizedCount > 0) {
      changes.push(`Added alt text to ${optimizedCount} images and enabled lazy loading`);
    }
  }

  private async addStructuredData($: cheerio.CheerioAPI, changes: string[]) {
    // Add basic organization structured data
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": $('title').text() || "Professional Services",
      "url": "{{WEBSITE_URL}}",
      "description": $('meta[name="description"]').attr('content') || "Professional services website",
      "sameAs": []
    };

    const scriptTag = `<script type="application/ld+json">${JSON.stringify(structuredData, null, 2)}</script>`;
    $('head').append(scriptTag);
    
    changes.push("Added structured data for better search engine understanding");
  }

  private async addCanonicalUrl($: cheerio.CheerioAPI, changes: string[]) {
    if ($('link[rel="canonical"]').length === 0) {
      $('head').append('<link rel="canonical" href="{{CANONICAL_URL}}">');
      changes.push("Added canonical URL tag");
    }
  }

  private async optimizeInternalLinking($: cheerio.CheerioAPI, changes: string[]) {
    // Add internal links to improve site structure
    const contentElements = $('p, div').filter((_, el) => {
      const text = $(el).text();
      return text.length > 50 && text.length < 200 && $(el).find('a').length === 0;
    });

    let linksAdded = 0;
    const linkOpportunities = [
      { text: "about us", href: "/about" },
      { text: "contact", href: "/contact" },
      { text: "services", href: "/services" },
      { text: "blog", href: "/blog" }
    ];

    contentElements.slice(0, 3).each((_, el) => {
      const text = $(el).text().toLowerCase();
      
      linkOpportunities.forEach(opportunity => {
        if (text.includes(opportunity.text) && Math.random() > 0.5) {
          const currentHtml = $(el).html();
          const regex = new RegExp(`\\b${opportunity.text}\\b`, 'gi');
          const newHtml = currentHtml?.replace(regex, `<a href="${opportunity.href}">${opportunity.text}</a>`);
          
          if (newHtml && newHtml !== currentHtml) {
            $(el).html(newHtml);
            linksAdded++;
          }
        }
      });
    });

    if (linksAdded > 0) {
      changes.push(`Added ${linksAdded} internal links to improve site structure`);
    }
  }

  private async addOpenGraphTags($: cheerio.CheerioAPI, changes: string[]) {
    const title = $('title').text();
    const description = $('meta[name="description"]').attr('content');
    
    if ($('meta[property="og:title"]').length === 0) {
      $('head').append(`<meta property="og:title" content="${title}">`);
    }
    
    if ($('meta[property="og:description"]').length === 0) {
      $('head').append(`<meta property="og:description" content="${description}">`);
    }
    
    if ($('meta[property="og:type"]').length === 0) {
      $('head').append('<meta property="og:type" content="website">');
    }
    
    if ($('meta[property="og:url"]').length === 0) {
      $('head').append('<meta property="og:url" content="{{WEBSITE_URL}}">');
    }
    
    changes.push("Added Open Graph tags for better social media sharing");
  }

  async generateSitemap(websiteId: number): Promise<string> {
    // Generate basic sitemap XML
    const website = await storage.getWebsite(websiteId);
    const blogPosts = await storage.getBlogPosts(websiteId);
    
    const baseUrl = website?.url || "https://example.com";
    
    let sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${baseUrl}/about</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${baseUrl}/contact</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${baseUrl}/privacy</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>yearly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>${baseUrl}/terms</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>yearly</changefreq>
    <priority>0.5</priority>
  </url>`;

    // Add blog posts
    blogPosts.forEach(post => {
      const postDate = post.publishedAt?.toISOString().split('T')[0] || new Date().toISOString().split('T')[0];
      sitemap += `
  <url>
    <loc>${baseUrl}/blog/${post.id}</loc>
    <lastmod>${postDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>`;
    });

    sitemap += `
</urlset>`;

    return sitemap;
  }

  private async logOptimization(websiteId: number, changes: string[]) {
    await storage.createActivityLog({
      websiteId,
      action: "seo_optimization_completed",
      description: `SEO optimization completed with ${changes.length} improvements`,
      type: "success",
      metadata: { changes }
    });
  }
}

export const seoOptimizer = new SEOOptimizer();
