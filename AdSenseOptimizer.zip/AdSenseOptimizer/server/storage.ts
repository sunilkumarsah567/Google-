import { 
  users, websites, optimizationTasks, blogPosts, configurations, activityLogs,
  type User, type InsertUser, type Website, type InsertWebsite,
  type OptimizationTask, type BlogPost, type InsertBlogPost,
  type Configuration, type InsertConfiguration, type ActivityLog, type InsertActivityLog
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Websites
  getWebsite(id: number): Promise<Website | undefined>;
  getWebsiteByUrl(url: string): Promise<Website | undefined>;
  getAllWebsites(): Promise<Website[]>;
  createWebsite(website: InsertWebsite): Promise<Website>;
  updateWebsite(id: number, updates: Partial<Website>): Promise<Website | undefined>;
  
  // Optimization Tasks
  getOptimizationTasks(websiteId: number): Promise<OptimizationTask[]>;
  createOptimizationTask(task: Omit<OptimizationTask, 'id' | 'createdAt' | 'completedAt'>): Promise<OptimizationTask>;
  updateOptimizationTask(id: number, updates: Partial<OptimizationTask>): Promise<OptimizationTask | undefined>;
  
  // Blog Posts
  getBlogPosts(websiteId: number): Promise<BlogPost[]>;
  getRecentBlogPosts(websiteId: number, limit?: number): Promise<BlogPost[]>;
  createBlogPost(post: InsertBlogPost & { websiteId: number }): Promise<BlogPost>;
  updateBlogPost(id: number, updates: Partial<BlogPost>): Promise<BlogPost | undefined>;
  
  // Configuration
  getConfiguration(websiteId: number): Promise<Configuration | undefined>;
  createConfiguration(config: InsertConfiguration): Promise<Configuration>;
  updateConfiguration(websiteId: number, updates: Partial<Configuration>): Promise<Configuration | undefined>;
  
  // Activity Logs
  getActivityLogs(websiteId: number, limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private websites: Map<number, Website> = new Map();
  private optimizationTasks: Map<number, OptimizationTask> = new Map();
  private blogPosts: Map<number, BlogPost> = new Map();
  private configurations: Map<number, Configuration> = new Map();
  private activityLogs: Map<number, ActivityLog> = new Map();
  
  private currentUserId = 1;
  private currentWebsiteId = 1;
  private currentTaskId = 1;
  private currentPostId = 1;
  private currentConfigId = 1;
  private currentLogId = 1;

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Websites
  async getWebsite(id: number): Promise<Website | undefined> {
    return this.websites.get(id);
  }

  async getWebsiteByUrl(url: string): Promise<Website | undefined> {
    return Array.from(this.websites.values()).find(website => website.url === url);
  }

  async getAllWebsites(): Promise<Website[]> {
    return Array.from(this.websites.values());
  }

  async createWebsite(website: InsertWebsite): Promise<Website> {
    const id = this.currentWebsiteId++;
    const now = new Date();
    const newWebsite: Website = {
      ...website,
      id,
      title: website.title || null,
      status: "pending",
      seoScore: 0,
      speedScore: 0,
      mobileScore: 0,
      adsenseReady: 0,
      createdAt: now,
      updatedAt: now,
    };
    this.websites.set(id, newWebsite);
    return newWebsite;
  }

  async updateWebsite(id: number, updates: Partial<Website>): Promise<Website | undefined> {
    const website = this.websites.get(id);
    if (!website) return undefined;
    
    const updated = { ...website, ...updates, updatedAt: new Date() };
    this.websites.set(id, updated);
    return updated;
  }

  // Optimization Tasks
  async getOptimizationTasks(websiteId: number): Promise<OptimizationTask[]> {
    return Array.from(this.optimizationTasks.values())
      .filter(task => task.websiteId === websiteId)
      .sort((a, b) => a.createdAt!.getTime() - b.createdAt!.getTime());
  }

  async createOptimizationTask(task: Omit<OptimizationTask, 'id' | 'createdAt' | 'completedAt'>): Promise<OptimizationTask> {
    const id = this.currentTaskId++;
    const newTask: OptimizationTask = {
      ...task,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.optimizationTasks.set(id, newTask);
    return newTask;
  }

  async updateOptimizationTask(id: number, updates: Partial<OptimizationTask>): Promise<OptimizationTask | undefined> {
    const task = this.optimizationTasks.get(id);
    if (!task) return undefined;
    
    const updated = { ...task, ...updates };
    if (updates.status === "completed") {
      updated.completedAt = new Date();
    }
    this.optimizationTasks.set(id, updated);
    return updated;
  }

  // Blog Posts
  async getBlogPosts(websiteId: number): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values())
      .filter(post => post.websiteId === websiteId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async getRecentBlogPosts(websiteId: number, limit = 10): Promise<BlogPost[]> {
    const posts = await this.getBlogPosts(websiteId);
    return posts.slice(0, limit);
  }

  async createBlogPost(post: InsertBlogPost & { websiteId: number }): Promise<BlogPost> {
    const id = this.currentPostId++;
    const newPost: BlogPost = {
      ...post,
      id,
      createdAt: new Date(),
      publishedAt: post.status === "published" ? new Date() : null,
    };
    this.blogPosts.set(id, newPost);
    return newPost;
  }

  async updateBlogPost(id: number, updates: Partial<BlogPost>): Promise<BlogPost | undefined> {
    const post = this.blogPosts.get(id);
    if (!post) return undefined;
    
    const updated = { ...post, ...updates };
    if (updates.status === "published" && !post.publishedAt) {
      updated.publishedAt = new Date();
    }
    this.blogPosts.set(id, updated);
    return updated;
  }

  // Configuration
  async getConfiguration(websiteId: number): Promise<Configuration | undefined> {
    return Array.from(this.configurations.values())
      .find(config => config.websiteId === websiteId);
  }

  async createConfiguration(config: InsertConfiguration): Promise<Configuration> {
    const id = this.currentConfigId++;
    const newConfig: Configuration = {
      ...config,
      id,
      updatedAt: new Date(),
    };
    this.configurations.set(id, newConfig);
    return newConfig;
  }

  async updateConfiguration(websiteId: number, updates: Partial<Configuration>): Promise<Configuration | undefined> {
    const config = Array.from(this.configurations.values())
      .find(c => c.websiteId === websiteId);
    if (!config) return undefined;
    
    const updated = { ...config, ...updates, updatedAt: new Date() };
    this.configurations.set(config.id, updated);
    return updated;
  }

  // Activity Logs
  async getActivityLogs(websiteId: number, limit = 50): Promise<ActivityLog[]> {
    return Array.from(this.activityLogs.values())
      .filter(log => log.websiteId === websiteId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(0, limit);
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentLogId++;
    const newLog: ActivityLog = {
      ...log,
      id,
      createdAt: new Date(),
    };
    this.activityLogs.set(id, newLog);
    return newLog;
  }
}

export const storage = new MemStorage();
