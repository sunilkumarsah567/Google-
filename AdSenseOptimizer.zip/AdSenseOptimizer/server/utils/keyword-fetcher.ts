import { apiRequest } from "../routes";

export interface KeywordData {
  keyword: string;
  searchVolume: number;
  difficulty: number;
  trend: "up" | "down" | "stable";
}

export interface TrendingTopic {
  title: string;
  keywords: string[];
  category: string;
  relevanceScore: number;
}

export class KeywordFetcher {
  async getTrendingKeywords(category = "technology", limit = 20): Promise<KeywordData[]> {
    try {
      // Use Google Trends RSS feed for trending topics
      const trendsResponse = await fetch(`https://trends.google.com/trends/trendingsearches/daily/rss?geo=US`);
      const trendsXml = await trendsResponse.text();
      
      // Parse RSS and extract keywords
      const keywords = this.parseRSSKeywords(trendsXml, category);
      
      // Add mock search volume and difficulty (in real app, use free keyword tools)
      return keywords.slice(0, limit).map(keyword => ({
        keyword,
        searchVolume: Math.floor(Math.random() * 10000) + 1000,
        difficulty: Math.floor(Math.random() * 100) + 1,
        trend: Math.random() > 0.5 ? "up" : Math.random() > 0.5 ? "stable" : "down"
      }));
    } catch (error) {
      console.error("Error fetching trending keywords:", error);
      // Fallback keywords by category
      return this.getFallbackKeywords(category, limit);
    }
  }

  async getTrendingTopics(category = "technology"): Promise<TrendingTopic[]> {
    try {
      // Use Reddit RSS for trending discussions
      const redditResponse = await fetch(`https://www.reddit.com/r/${category}.rss`);
      const redditXml = await redditResponse.text();
      
      return this.parseRedditTopics(redditXml, category);
    } catch (error) {
      console.error("Error fetching trending topics:", error);
      return this.getFallbackTopics(category);
    }
  }

  async getRelatedKeywords(baseKeyword: string): Promise<string[]> {
    try {
      // Use free keyword suggestion APIs or RSS feeds
      const suggestions = await this.fetchKeywordSuggestions(baseKeyword);
      return suggestions;
    } catch (error) {
      console.error("Error fetching related keywords:", error);
      return this.generateRelatedKeywords(baseKeyword);
    }
  }

  private parseRSSKeywords(xml: string, category: string): string[] {
    // Simple XML parsing to extract trending terms
    const titleMatches = xml.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/g) || [];
    const keywords: string[] = [];
    
    titleMatches.forEach(match => {
      const title = match.replace(/<title><!\[CDATA\[/, "").replace(/\]\]><\/title>/, "");
      // Extract meaningful keywords from titles
      const words = title.toLowerCase()
        .split(/[\s,.-]+/)
        .filter(word => word.length > 3 && !this.isStopWord(word));
      keywords.push(...words);
    });
    
    return [...new Set(keywords)].slice(0, 50);
  }

  private parseRedditTopics(xml: string, category: string): TrendingTopic[] {
    const topics: TrendingTopic[] = [];
    const titleMatches = xml.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/g) || [];
    
    titleMatches.slice(0, 10).forEach(match => {
      const title = match.replace(/<title><!\[CDATA\[/, "").replace(/\]\]><\/title>/, "");
      if (title && title !== category) {
        const keywords = this.extractKeywordsFromTitle(title);
        topics.push({
          title,
          keywords,
          category,
          relevanceScore: Math.random() * 100
        });
      }
    });
    
    return topics;
  }

  private async fetchKeywordSuggestions(keyword: string): Promise<string[]> {
    // In a real implementation, use free APIs like:
    // - Google Suggest API
    // - Bing Suggest API
    // - Ubersuggest free tier
    
    const suggestions = this.generateRelatedKeywords(keyword);
    return suggestions;
  }

  private generateRelatedKeywords(baseKeyword: string): string[] {
    const prefixes = ["best", "top", "how to", "what is", "benefits of", "guide to"];
    const suffixes = ["2024", "guide", "tips", "review", "tutorial", "analysis"];
    const related = [];
    
    prefixes.forEach(prefix => {
      related.push(`${prefix} ${baseKeyword}`);
    });
    
    suffixes.forEach(suffix => {
      related.push(`${baseKeyword} ${suffix}`);
    });
    
    return related;
  }

  private extractKeywordsFromTitle(title: string): string[] {
    return title.toLowerCase()
      .split(/[\s,.-]+/)
      .filter(word => word.length > 3 && !this.isStopWord(word))
      .slice(0, 5);
  }

  private isStopWord(word: string): boolean {
    const stopWords = [
      "the", "and", "for", "are", "but", "not", "you", "all", "can", "had", 
      "her", "was", "one", "our", "out", "day", "get", "has", "him", "his", 
      "how", "its", "may", "new", "now", "old", "see", "two", "who", "boy", 
      "did", "from", "this", "that", "with", "have", "been", "will"
    ];
    return stopWords.includes(word.toLowerCase());
  }

  private getFallbackKeywords(category: string, limit: number): KeywordData[] {
    const fallbackByCategory: Record<string, string[]> = {
      technology: [
        "artificial intelligence", "machine learning", "blockchain", "cybersecurity",
        "cloud computing", "data science", "mobile apps", "software development",
        "IoT devices", "quantum computing", "5G technology", "virtual reality"
      ],
      business: [
        "digital marketing", "e-commerce", "startup funding", "remote work",
        "business strategy", "leadership", "productivity", "sales techniques",
        "market analysis", "customer retention", "brand building", "innovation"
      ],
      health: [
        "mental health", "nutrition", "fitness", "wellness", "healthcare technology",
        "medical research", "preventive care", "healthy lifestyle", "exercise",
        "diet trends", "sleep health", "stress management"
      ],
      lifestyle: [
        "travel tips", "home decor", "fashion trends", "cooking", "personal growth",
        "minimalism", "sustainability", "hobbies", "entertainment", "relationships",
        "work-life balance", "self-care"
      ]
    };

    const keywords = fallbackByCategory[category] || fallbackByCategory.technology;
    return keywords.slice(0, limit).map(keyword => ({
      keyword,
      searchVolume: Math.floor(Math.random() * 10000) + 1000,
      difficulty: Math.floor(Math.random() * 100) + 1,
      trend: Math.random() > 0.5 ? "up" : "stable" as "up" | "stable"
    }));
  }

  private getFallbackTopics(category: string): TrendingTopic[] {
    const fallbackTopics: Record<string, TrendingTopic[]> = {
      technology: [
        {
          title: "The Future of AI in Software Development",
          keywords: ["artificial intelligence", "software", "development", "automation"],
          category: "technology",
          relevanceScore: 95
        },
        {
          title: "Cybersecurity Trends for 2024",
          keywords: ["cybersecurity", "trends", "data protection", "security"],
          category: "technology",
          relevanceScore: 92
        }
      ],
      business: [
        {
          title: "Remote Work Best Practices",
          keywords: ["remote work", "productivity", "team management"],
          category: "business",
          relevanceScore: 88
        }
      ]
    };

    return fallbackTopics[category] || fallbackTopics.technology;
  }
}

export const keywordFetcher = new KeywordFetcher();
