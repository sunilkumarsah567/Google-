import JSZip from "jszip";
import { readFileSync, existsSync } from "fs";
import { join } from "path";

export interface DeploymentOptions {
  includeSourceCode: boolean;
  includeDatabase: boolean;
  platform: "general" | "cpanel" | "vercel" | "netlify";
}

export class DeploymentPackager {
  async createDeploymentPackage(options: DeploymentOptions = { 
    includeSourceCode: true, 
    includeDatabase: true, 
    platform: "general" 
  }): Promise<Buffer> {
    const zip = new JSZip();

    // Add source code files
    if (options.includeSourceCode) {
      await this.addSourceFiles(zip);
    }

    // Add deployment configurations
    await this.addDeploymentConfigs(zip, options.platform);

    // Add documentation
    await this.addDocumentation(zip, options);

    // Add database setup
    if (options.includeDatabase) {
      await this.addDatabaseSetup(zip);
    }

    return await zip.generateAsync({ type: "nodebuffer" });
  }

  private async addSourceFiles(zip: JSZip) {
    // Server files
    const serverFolder = zip.folder("server");
    const serverFiles = [
      "index.ts",
      "routes.ts", 
      "storage.ts",
      "vite.ts"
    ];

    for (const file of serverFiles) {
      try {
        const content = readFileSync(join(process.cwd(), "server", file), "utf8");
        serverFolder!.file(file, content);
      } catch (error) {
        console.log(`Skipping ${file}: ${error}`);
      }
    }

    // Server services
    const servicesFolder = serverFolder!.folder("services");
    const serviceFiles = [
      "website-analyzer.ts",
      "seo-optimizer.ts", 
      "blog-generator.ts",
      "export-service.ts"
    ];

    for (const file of serviceFiles) {
      try {
        const content = readFileSync(join(process.cwd(), "server/services", file), "utf8");
        servicesFolder!.file(file, content);
      } catch (error) {
        console.log(`Skipping service ${file}: ${error}`);
      }
    }

    // Server utils
    const utilsFolder = serverFolder!.folder("utils");
    const utilFiles = [
      "keyword-fetcher.ts",
      "rss-parser.ts"
    ];

    for (const file of utilFiles) {
      try {
        const content = readFileSync(join(process.cwd(), "server/utils", file), "utf8");
        utilsFolder!.file(file, content);
      } catch (error) {
        console.log(`Skipping util ${file}: ${error}`);
      }
    }

    // Client files
    const clientFolder = zip.folder("client");
    const clientSrcFolder = clientFolder!.folder("src");

    // Add main client files
    const clientFiles = [
      "App.tsx",
      "main.tsx",
      "index.css"
    ];

    for (const file of clientFiles) {
      try {
        const content = readFileSync(join(process.cwd(), "client/src", file), "utf8");
        clientSrcFolder!.file(file, content);
      } catch (error) {
        console.log(`Skipping client ${file}: ${error}`);
      }
    }

    // Add client components
    const componentsFolder = clientSrcFolder!.folder("components");
    const componentFiles = [
      "sidebar.tsx",
      "dashboard-header.tsx",
      "url-input.tsx",
      "metrics-cards.tsx",
      "optimization-progress.tsx",
      "auto-blogging-panel.tsx", 
      "configuration-panel.tsx",
      "activity-log.tsx"
    ];

    for (const file of componentFiles) {
      try {
        const content = readFileSync(join(process.cwd(), "client/src/components", file), "utf8");
        componentsFolder!.file(file, content);
      } catch (error) {
        console.log(`Skipping component ${file}: ${error}`);
      }
    }

    // Add client pages
    const pagesFolder = clientSrcFolder!.folder("pages");
    try {
      const content = readFileSync(join(process.cwd(), "client/src/pages/dashboard.tsx"), "utf8");
      pagesFolder!.file("dashboard.tsx", content);
    } catch (error) {
      console.log(`Skipping dashboard page: ${error}`);
    }

    // Add lib files
    const libFolder = clientSrcFolder!.folder("lib");
    try {
      const content = readFileSync(join(process.cwd(), "client/src/lib/queryClient.ts"), "utf8");
      libFolder!.file("queryClient.ts", content);
    } catch (error) {
      console.log(`Skipping queryClient: ${error}`);
    }

    // Add shared schema
    const sharedFolder = zip.folder("shared");
    try {
      const content = readFileSync(join(process.cwd(), "shared/schema.ts"), "utf8");
      sharedFolder!.file("schema.ts", content);
    } catch (error) {
      console.log(`Skipping schema: ${error}`);
    }

    // Add configuration files
    const configFiles = [
      "package.json",
      "tsconfig.json", 
      "vite.config.ts",
      "tailwind.config.ts",
      "postcss.config.js",
      "components.json"
    ];

    for (const file of configFiles) {
      try {
        const content = readFileSync(join(process.cwd(), file), "utf8");
        zip.file(file, content);
      } catch (error) {
        console.log(`Skipping config ${file}: ${error}`);
      }
    }
  }

  private async addDeploymentConfigs(zip: JSZip, platform: string) {
    const deployFolder = zip.folder("deployment");

    // Docker configuration
    const dockerFile = `FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .
RUN npm run build

EXPOSE 5000

CMD ["npm", "start"]`;

    deployFolder!.file("Dockerfile", dockerFile);

    // Docker Compose
    const dockerCompose = `version: '3.8'
services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
    volumes:
      - ./data:/app/data
    restart: unless-stopped`;

    deployFolder!.file("docker-compose.yml", dockerCompose);

    // Platform-specific configs
    switch (platform) {
      case "cpanel":
        // cPanel .htaccess
        const htaccess = `RewriteEngine On
RewriteRule ^(.*)$ index.html [QSA,L]

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"

# Cache static assets
<filesMatch "\\.(css|js|png|jpg|jpeg|gif|ico|svg)$">
  ExpiresActive On
  ExpiresDefault "access plus 1 month"
</filesMatch>`;

        deployFolder!.file("cpanel/.htaccess", htaccess);

        // cPanel deployment script
        const cPanelDeploy = `#!/bin/bash
# cPanel Deployment Script
echo "Deploying to cPanel..."

# Upload files via FTP
# Update this with your cPanel credentials
FTP_HOST="your-domain.com"
FTP_USER="your-username"
FTP_PASS="your-password"

# Create directories
curl -T dist/ ftp://$FTP_USER:$FTP_PASS@$FTP_HOST/public_html/

echo "Deployment complete!"`;

        deployFolder!.file("cpanel/deploy.sh", cPanelDeploy);
        break;

      case "vercel":
        // Vercel configuration
        const vercelConfig = {
          "version": 2,
          "builds": [
            {
              "src": "server/index.ts",
              "use": "@vercel/node"
            },
            {
              "src": "client/**/*",
              "use": "@vercel/static-build"
            }
          ],
          "routes": [
            {
              "src": "/api/(.*)",
              "dest": "/server/index.ts"
            },
            {
              "src": "/(.*)",
              "dest": "/client/$1"
            }
          ]
        };

        deployFolder!.file("vercel/vercel.json", JSON.stringify(vercelConfig, null, 2));
        break;

      case "netlify":
        // Netlify configuration
        const netlifyToml = `[build]
  command = "npm run build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200`;

        deployFolder!.file("netlify/netlify.toml", netlifyToml);
        break;
    }

    // General deployment script
    const deployScript = `#!/bin/bash
# General Deployment Script

echo "Starting deployment..."

# Install dependencies
npm install

# Build the application
npm run build

# Start the application
echo "Starting server..."
npm start

echo "Deployment complete! Application running on http://localhost:5000"`;

    deployFolder!.file("deploy.sh", deployScript);

    // Environment template
    const envTemplate = `# Environment Variables Template
NODE_ENV=production
PORT=5000

# Optional: Add your API keys here
# OPENAI_API_KEY=your_openai_key_here
# GOOGLE_ANALYTICS_ID=your_ga_id_here

# Database configuration (if using external database)
# DATABASE_URL=your_database_connection_string`;

    deployFolder!.file(".env.template", envTemplate);
  }

  private async addDocumentation(zip: JSZip, options: DeploymentOptions) {
    const docsFolder = zip.folder("docs");

    // Main README
    const readme = `# AdSense Pro - Website Optimization Platform

## Overview
Complete SaaS platform for automated website optimization and AdSense approval preparation.

## Features
- ✅ Automated website analysis and optimization
- ✅ SEO optimization with meta tags, structured data
- ✅ Speed optimization and mobile responsiveness
- ✅ Auto-blogging system with trending keywords
- ✅ Export optimized websites as ZIP files
- ✅ Real-time progress tracking and activity logs

## Installation

### Option 1: Local Development
\`\`\`bash
npm install
npm run dev
\`\`\`

### Option 2: Production Deployment
\`\`\`bash
npm install
npm run build
npm start
\`\`\`

### Option 3: Docker Deployment
\`\`\`bash
docker-compose up -d
\`\`\`

## Usage

1. **Enter Website URL**: Input any website URL to start analysis
2. **Wait for Analysis**: System automatically analyzes SEO, speed, mobile, and AdSense readiness
3. **Configure Settings**: Adjust auto-blogging frequency and target keywords
4. **Export Optimized Site**: Download complete optimized website as ZIP file

## Features Detail

### Website Analysis
- SEO score calculation
- Page speed analysis
- Mobile responsiveness check
- AdSense readiness assessment

### Auto-Blogging System
- Fetches trending keywords from Google Trends
- Generates human-like blog posts
- Configurable posting frequency (1h, 2h, 6h, 24h)
- RSS feed integration for current news

### Export Functionality
- Complete optimized HTML/CSS/JS
- AdSense-ready ad placements
- Required pages (Privacy, Terms, About, Contact)
- Configuration files and documentation

## API Endpoints

- \`POST /api/websites/analyze\` - Start website analysis
- \`GET /api/websites/:id/tasks\` - Get optimization progress
- \`POST /api/websites/:id/blog/generate\` - Generate blog post
- \`POST /api/websites/:id/export\` - Export optimized website
- \`PUT /api/websites/:id/config\` - Update configuration

## Configuration

Edit the configuration panel to customize:
- Auto-blogging frequency
- Target keywords
- SEO optimization settings
- Site category

## Support

For issues or questions, check the documentation in the \`docs/\` folder.
`;

    docsFolder!.file("README.md", readme);

    // Installation guide
    const installGuide = `# Installation Guide

## System Requirements
- Node.js 18 or higher
- npm or yarn package manager
- 2GB RAM minimum
- 10GB storage space

## Platform-Specific Installation

### cPanel Hosting
1. Upload all files to public_html directory
2. Install Node.js from cPanel
3. Run deployment script
4. Configure domain settings

### VPS/Cloud Server
1. Clone or upload project files
2. Install dependencies: \`npm install\`
3. Build project: \`npm run build\`
4. Start with PM2: \`pm2 start server/index.js\`

### Docker Container
1. Build image: \`docker build -t adsense-pro .\`
2. Run container: \`docker run -p 5000:5000 adsense-pro\`

## Environment Configuration
Copy \`.env.template\` to \`.env\` and configure:
- PORT: Server port (default: 5000)
- NODE_ENV: Environment (production/development)

## Troubleshooting
- Check logs in \`logs/\` directory
- Ensure all dependencies are installed
- Verify port is not in use
- Check file permissions on Linux/Unix
`;

    docsFolder!.file("INSTALLATION.md", installGuide);

    // API documentation
    const apiDocs = `# API Documentation

## Authentication
Currently no authentication required for local deployment.

## Endpoints

### Website Management

#### Analyze Website
\`POST /api/websites/analyze\`

Request:
\`\`\`json
{
  "url": "https://example.com",
  "title": "Optional title"
}
\`\`\`

Response:
\`\`\`json
{
  "website": {
    "id": 1,
    "url": "https://example.com",
    "status": "analyzing"
  }
}
\`\`\`

#### Get Analysis Results
\`GET /api/websites/:id/analysis\`

Response:
\`\`\`json
{
  "website": {
    "id": 1,
    "seoScore": 85,
    "speedScore": 72,
    "mobileScore": 90,
    "adsenseReady": 78
  }
}
\`\`\`

### Blog Management

#### Generate Blog Post
\`POST /api/websites/:id/blog/generate\`

Response:
\`\`\`json
{
  "id": 1,
  "title": "Generated blog post title",
  "content": "Full blog post content...",
  "keywords": ["keyword1", "keyword2"]
}
\`\`\`

### Export

#### Export Optimized Website
\`POST /api/websites/:id/export\`

Request:
\`\`\`json
{
  "includeOptimizations": true,
  "includeAdSenseCode": true,
  "includeAnalytics": false
}
\`\`\`

Returns ZIP file download.
`;

    docsFolder!.file("API.md", apiDocs);
  }

  private async addDatabaseSetup(zip: JSZip) {
    const dbFolder = zip.folder("database");

    // Database migration files
    const migrations = `-- Database Setup for AdSense Pro
-- Run these commands to set up PostgreSQL database

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE websites (
  id SERIAL PRIMARY KEY,
  url TEXT NOT NULL,
  title TEXT,
  status VARCHAR(50) DEFAULT 'pending',
  seo_score INTEGER DEFAULT 0,
  speed_score INTEGER DEFAULT 0,
  mobile_score INTEGER DEFAULT 0,
  adsense_ready INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE optimization_tasks (
  id SERIAL PRIMARY KEY,
  website_id INTEGER REFERENCES websites(id),
  name TEXT NOT NULL,
  description TEXT,
  status VARCHAR(50) DEFAULT 'pending',
  progress INTEGER DEFAULT 0,
  result TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP
);

CREATE TABLE blog_posts (
  id SERIAL PRIMARY KEY,
  website_id INTEGER REFERENCES websites(id),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  keywords TEXT[],
  category TEXT,
  status VARCHAR(50) DEFAULT 'draft',
  published_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE configurations (
  id SERIAL PRIMARY KEY,
  website_id INTEGER REFERENCES websites(id),
  auto_blogging_enabled BOOLEAN DEFAULT true,
  post_frequency VARCHAR(10) DEFAULT '1h',
  target_keywords TEXT[] DEFAULT '{}',
  site_category TEXT DEFAULT 'Technology',
  auto_meta_tags BOOLEAN DEFAULT true,
  generate_sitemap BOOLEAN DEFAULT true,
  internal_linking BOOLEAN DEFAULT true,
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE activity_logs (
  id SERIAL PRIMARY KEY,
  website_id INTEGER REFERENCES websites(id),
  action TEXT NOT NULL,
  description TEXT NOT NULL,
  type VARCHAR(20) NOT NULL,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_websites_url ON websites(url);
CREATE INDEX idx_blog_posts_website_id ON blog_posts(website_id);
CREATE INDEX idx_activity_logs_website_id ON activity_logs(website_id);
CREATE INDEX idx_optimization_tasks_website_id ON optimization_tasks(website_id);
`;

    dbFolder!.file("schema.sql", migrations);

    // Database connection example
    const dbConnection = `// Database Connection Example
// For PostgreSQL deployment

import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './shared/schema';

const connectionString = process.env.DATABASE_URL || 'postgresql://user:password@localhost:5432/adsense_pro';

const client = postgres(connectionString);
export const db = drizzle(client, { schema });

// For production, ensure proper connection pooling and error handling
`;

    dbFolder!.file("connection.ts", dbConnection);
  }
}

export const deploymentPackager = new DeploymentPackager();