export interface RSSFeed {
  title: string;
  link: string;
  description: string;
  items: RSSItem[];
}

export interface RSSItem {
  title: string;
  link: string;
  description: string;
  pubDate: Date;
  category?: string;
  keywords: string[];
}

export class RSSParser {
  async parseRSSFeed(url: string): Promise<RSSFeed> {
    try {
      const response = await fetch(url);
      const xmlText = await response.text();
      return this.parseXML(xmlText);
    } catch (error) {
      console.error("Error parsing RSS feed:", error);
      throw new Error("Failed to parse RSS feed");
    }
  }

  async getNewsFromMultipleSources(category = "technology"): Promise<RSSItem[]> {
    const rssSources = this.getRSSSourcesByCategory(category);
    const allItems: RSSItem[] = [];

    for (const source of rssSources) {
      try {
        const feed = await this.parseRSSFeed(source.url);
        const processedItems = feed.items.map(item => ({
          ...item,
          category: source.category,
          keywords: this.extractKeywords(item.title + " " + item.description)
        }));
        allItems.push(...processedItems);
      } catch (error) {
        console.error(`Error fetching from ${source.url}:`, error);
      }
    }

    // Sort by publication date (newest first)
    return allItems.sort((a, b) => b.pubDate.getTime() - a.pubDate.getTime());
  }

  private parseXML(xml: string): RSSFeed {
    // Basic XML parsing for RSS feeds
    const titleMatch = xml.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>|<title>(.*?)<\/title>/);
    const linkMatch = xml.match(/<link>(.*?)<\/link>/);
    const descMatch = xml.match(/<description><!\[CDATA\[(.*?)\]\]><\/description>|<description>(.*?)<\/description>/);

    const title = titleMatch ? (titleMatch[1] || titleMatch[2] || "").trim() : "";
    const link = linkMatch ? linkMatch[1].trim() : "";
    const description = descMatch ? (descMatch[1] || descMatch[2] || "").trim() : "";

    // Extract items
    const itemMatches = xml.match(/<item>(.*?)<\/item>/gs) || [];
    const items: RSSItem[] = [];

    itemMatches.forEach(itemXml => {
      const item = this.parseRSSItem(itemXml);
      if (item) {
        items.push(item);
      }
    });

    return {
      title,
      link,
      description,
      items
    };
  }

  private parseRSSItem(itemXml: string): RSSItem | null {
    try {
      const titleMatch = itemXml.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>|<title>(.*?)<\/title>/);
      const linkMatch = itemXml.match(/<link>(.*?)<\/link>/);
      const descMatch = itemXml.match(/<description><!\[CDATA\[(.*?)\]\]><\/description>|<description>(.*?)<\/description>/);
      const pubDateMatch = itemXml.match(/<pubDate>(.*?)<\/pubDate>/);

      if (!titleMatch) return null;

      const title = (titleMatch[1] || titleMatch[2] || "").trim();
      const link = linkMatch ? linkMatch[1].trim() : "";
      const description = descMatch ? (descMatch[1] || descMatch[2] || "").trim() : "";
      const pubDateStr = pubDateMatch ? pubDateMatch[1].trim() : "";

      let pubDate = new Date();
      if (pubDateStr) {
        try {
          pubDate = new Date(pubDateStr);
        } catch {
          pubDate = new Date();
        }
      }

      const keywords = this.extractKeywords(title + " " + description);

      return {
        title,
        link,
        description,
        pubDate,
        keywords
      };
    } catch (error) {
      console.error("Error parsing RSS item:", error);
      return null;
    }
  }

  private extractKeywords(text: string): string[] {
    if (!text) return [];

    // Clean HTML tags
    const cleanText = text.replace(/<[^>]*>/g, "");
    
    // Extract meaningful words
    const words = cleanText.toLowerCase()
      .split(/[\s,.-]+/)
      .filter(word => 
        word.length > 3 && 
        !this.isStopWord(word) &&
        /^[a-z]+$/.test(word)
      );

    // Remove duplicates and return top keywords
    return [...new Set(words)].slice(0, 10);
  }

  private isStopWord(word: string): boolean {
    const stopWords = [
      "the", "and", "for", "are", "but", "not", "you", "all", "can", "had",
      "her", "was", "one", "our", "out", "day", "get", "has", "him", "his",
      "how", "its", "may", "new", "now", "old", "see", "two", "who", "boy",
      "did", "from", "this", "that", "with", "have", "been", "will", "they",
      "said", "each", "which", "their", "time", "would", "there", "what",
      "about", "could", "more", "than", "into", "after", "back", "other"
    ];
    return stopWords.includes(word.toLowerCase());
  }

  private getRSSSourcesByCategory(category: string) {
    const sources: Record<string, Array<{ url: string; category: string }>> = {
      technology: [
        { url: "https://techcrunch.com/feed/", category: "technology" },
        { url: "https://www.wired.com/feed/rss", category: "technology" },
        { url: "https://arstechnica.com/rss.xml", category: "technology" },
        { url: "https://www.theverge.com/rss/index.xml", category: "technology" }
      ],
      business: [
        { url: "https://feeds.bloomberg.com/markets/news.rss", category: "business" },
        { url: "https://www.entrepreneur.com/latest.rss", category: "business" },
        { url: "https://www.inc.com/rss.xml", category: "business" }
      ],
      health: [
        { url: "https://www.healthline.com/health/rss", category: "health" },
        { url: "https://www.webmd.com/rss/rss.aspx?RSSSource=RSS_PUBLIC", category: "health" }
      ],
      lifestyle: [
        { url: "https://lifehacker.com/rss", category: "lifestyle" },
        { url: "https://www.realsimple.com/rss.xml", category: "lifestyle" }
      ]
    };

    return sources[category] || sources.technology;
  }
}

export const rssParser = new RSSParser();
