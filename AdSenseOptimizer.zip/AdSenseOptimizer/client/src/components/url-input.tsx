import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Link, Rocket } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function UrlInput() {
  const [url, setUrl] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const analyzeMutation = useMutation({
    mutationFn: async (data: { url: string; title?: string }) => {
      const response = await apiRequest("POST", "/api/websites/analyze", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Analysis Started",
        description: "Website analysis has been initiated. Check the progress section for updates.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/websites"] });
      setUrl("");
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL",
        variant: "destructive",
      });
      return;
    }

    try {
      new URL(url); // Validate URL format
      analyzeMutation.mutate({ url });
    } catch {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL format (e.g., https://example.com)",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="mb-6">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <Link className="text-blue-600" size={20} />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-slate-900">Website URL Input</h2>
            <p className="text-slate-600">Enter your website URL to start automated optimization</p>
          </div>
        </div>
        
        <form onSubmit={handleSubmit} className="flex space-x-4">
          <Input
            type="url"
            placeholder="https://yourwebsite.com"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="flex-1"
            disabled={analyzeMutation.isPending}
          />
          <Button 
            type="submit"
            disabled={analyzeMutation.isPending}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Rocket className="mr-2" size={16} />
            {analyzeMutation.isPending ? "Analyzing..." : "Start Optimization"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
