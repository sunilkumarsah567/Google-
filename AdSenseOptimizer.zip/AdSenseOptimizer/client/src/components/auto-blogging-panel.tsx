import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, FileText, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AutoBloggingPanelProps {
  websiteId?: number;
}

export default function AutoBloggingPanel({ websiteId }: AutoBloggingPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: posts, isLoading } = useQuery({
    queryKey: ["/api/websites", websiteId, "blog"],
    enabled: !!websiteId,
  });

  const { data: config } = useQuery({
    queryKey: ["/api/websites", websiteId, "config"],
    enabled: !!websiteId,
  });

  const generatePostMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/websites/${websiteId}/blog/generate`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Blog Post Generated",
        description: "New blog post has been successfully generated and published.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/websites", websiteId, "blog"] });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Auto Blogging System
            <div className="flex items-center space-x-2">
              <Loader2 className="animate-spin" size={16} />
              <span className="text-sm text-slate-600">Loading...</span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="animate-spin" size={24} />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!websiteId) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Auto Blogging System</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600">No website selected. Start by analyzing a website URL.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const isActive = config?.autoBloggingEnabled;
  const recentPosts = posts?.slice(0, 2) || [];
  const totalPosts = posts?.length || 0;
  const thisWeekPosts = posts?.filter((post: any) => {
    const postDate = new Date(post.createdAt);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return postDate >= weekAgo;
  }).length || 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Auto Blogging System
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
            <span className={`text-sm font-medium ${isActive ? 'text-emerald-600' : 'text-slate-400'}`}>
              {isActive ? 'Active' : 'Inactive'}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Next Post Schedule */}
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <p className="font-medium text-slate-900">Next Post Schedule</p>
              <p className="text-sm text-slate-600">
                {config?.postFrequency === "1h" ? "Every hour" : 
                 config?.postFrequency === "2h" ? "Every 2 hours" : 
                 config?.postFrequency === "6h" ? "Every 6 hours" : "Daily"}
              </p>
            </div>
            <Clock className="text-slate-400" size={20} />
          </div>

          {/* Recent Posts */}
          <div className="border border-slate-200 rounded-lg divide-y divide-slate-200">
            {recentPosts.length > 0 ? (
              recentPosts.map((post: any) => (
                <div key={post.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-slate-900">{post.title}</p>
                      <p className="text-sm text-slate-600">
                        Published {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant={post.status === "published" ? "default" : "secondary"}>
                      {post.status}
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center">
                <p className="text-slate-600">No blog posts yet</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-2"
                  onClick={() => generatePostMutation.mutate()}
                  disabled={generatePostMutation.isPending}
                >
                  <FileText className="mr-2" size={14} />
                  {generatePostMutation.isPending ? "Generating..." : "Generate First Post"}
                </Button>
              </div>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-2xl font-bold text-slate-900">{totalPosts}</p>
              <p className="text-sm text-slate-600">Total Posts</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-2xl font-bold text-slate-900">{thisWeekPosts}</p>
              <p className="text-sm text-slate-600">This Week</p>
            </div>
          </div>

          {/* Generate Post Button */}
          {recentPosts.length > 0 && (
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full"
              onClick={() => generatePostMutation.mutate()}
              disabled={generatePostMutation.isPending}
            >
              <FileText className="mr-2" size={14} />
              {generatePostMutation.isPending ? "Generating..." : "Generate New Post"}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
