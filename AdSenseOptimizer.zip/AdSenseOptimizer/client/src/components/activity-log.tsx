import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, FileText, Gauge, AlertCircle } from "lucide-react";

interface ActivityLogProps {
  websiteId?: number;
}

export default function ActivityLog({ websiteId }: ActivityLogProps) {
  const { data: logs, isLoading } = useQuery({
    queryKey: ["/api/websites", websiteId, "activity"],
    enabled: !!websiteId,
  });

  if (!websiteId) {
    return (
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600">No website selected. Start by analyzing a website URL.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600">Loading activity...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!logs || logs.length === 0) {
    return (
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600">No activity logged yet.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getActivityIcon = (action: string, type: string) => {
    if (type === "error") {
      return <AlertCircle className="text-red-600" size={16} />;
    }
    
    if (action.includes("blog") || action.includes("post")) {
      return <FileText className="text-emerald-600" size={16} />;
    }
    
    if (action.includes("speed") || action.includes("optimization")) {
      return <Gauge className="text-amber-600" size={16} />;
    }
    
    return <CheckCircle className="text-blue-600" size={16} />;
  };

  const getActivityBgColor = (type: string) => {
    switch (type) {
      case "error":
        return "bg-red-100";
      case "success":
        return "bg-emerald-100";
      case "warning":
        return "bg-amber-100";
      default:
        return "bg-blue-100";
    }
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const activityDate = new Date(date);
    const diffInMinutes = Math.floor((now.getTime() - activityDate.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {logs.map((log: any) => (
            <div key={log.id} className="flex items-center space-x-4 p-3 hover:bg-slate-50 rounded-lg">
              <div className={`w-8 h-8 ${getActivityBgColor(log.type)} rounded-full flex items-center justify-center flex-shrink-0`}>
                {getActivityIcon(log.action, log.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900">{log.description}</p>
                <p className="text-xs text-slate-500">{formatTimeAgo(log.createdAt)}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-slate-200">
          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
            View all activity →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
