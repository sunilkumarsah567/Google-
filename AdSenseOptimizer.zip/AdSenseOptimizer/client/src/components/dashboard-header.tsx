import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function DashboardHeader() {
  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Website Optimization Dashboard</h1>
          <p className="text-slate-600 mt-1">Automated AdSense approval optimization system</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            onClick={() => {
              window.open('/api/download-platform', '_blank');
            }}
            className="border-emerald-600 text-emerald-600 hover:bg-emerald-50"
          >
            <Plus className="mr-2" size={16} />
            Download Platform ZIP
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="mr-2" size={16} />
            New Project
          </Button>
        </div>
      </div>
    </header>
  );
}
