import { TrendingUp, Home, Link, Search, FileText, Settings, Download, User } from "lucide-react";

export default function Sidebar() {
  const navItems = [
    { icon: Home, label: "Dashboard", href: "/", active: true },
    { icon: Link, label: "URL Analysis", href: "/analysis" },
    { icon: Search, label: "SEO Audit", href: "/seo" },
    { icon: FileText, label: "Auto Blogging", href: "/blog" },
    { icon: Settings, label: "Configuration", href: "/config" },
    { icon: Download, label: "Export", href: "/export" },
  ];

  return (
    <div className="bg-white w-64 shadow-sm border-r border-slate-200 flex flex-col">
      {/* Logo/Brand */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <TrendingUp className="text-white" size={16} />
          </div>
          <h1 className="text-xl font-bold text-slate-900">AdSense Pro</h1>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.href}>
              <a
                href={item.href}
                className={`sidebar-nav-item ${item.active ? 'active' : ''}`}
              >
                <item.icon size={16} />
                <span>{item.label}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-slate-200">
        <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-50">
          <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center">
            <User className="text-slate-600" size={14} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-900 truncate">Admin User</p>
            <p className="text-xs text-slate-500">Free Plan</p>
          </div>
        </div>
      </div>
    </div>
  );
}
