import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Clock, Circle, Loader2 } from "lucide-react";

interface OptimizationProgressProps {
  websiteId?: number;
}

export default function OptimizationProgress({ websiteId }: OptimizationProgressProps) {
  const { data: tasks, isLoading } = useQuery({
    queryKey: ["/api/websites", websiteId, "tasks"],
    enabled: !!websiteId,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Optimization Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="animate-spin" size={24} />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!tasks || tasks.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Optimization Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600">No optimization tasks found. Start by analyzing a website URL.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="text-emerald-600" size={20} />;
      case "running":
        return <Loader2 className="text-blue-600 animate-spin" size={20} />;
      default:
        return <Circle className="text-slate-400" size={20} />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return { text: "Complete", className: "text-emerald-600" };
      case "running":
        return { text: "Running", className: "text-blue-600" };
      default:
        return { text: "Pending", className: "text-slate-400" };
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Optimization Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {tasks.map((task: any) => {
            const statusInfo = getStatusText(task.status);
            
            return (
              <div key={task.id} className="flex items-center space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                    {getStatusIcon(task.status)}
                  </div>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-slate-900">{task.name}</p>
                  <p className="text-sm text-slate-600">{task.description}</p>
                </div>
                <span className={`font-medium ${statusInfo.className}`}>
                  {statusInfo.text}
                </span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
