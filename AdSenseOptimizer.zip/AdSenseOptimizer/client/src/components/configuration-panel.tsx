import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Download, Eye } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ConfigurationPanelProps {
  websiteId?: number;
}

export default function ConfigurationPanel({ websiteId }: ConfigurationPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: config, isLoading } = useQuery({
    queryKey: ["/api/websites", websiteId, "config"],
    enabled: !!websiteId,
  });

  const updateConfigMutation = useMutation({
    mutationFn: async (updates: any) => {
      const response = await apiRequest("PUT", `/api/websites/${websiteId}/config`, updates);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Configuration Updated",
        description: "Settings have been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/websites", websiteId, "config"] });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const exportMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/websites/${websiteId}/export`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          includeOptimizations: true,
          includeAdSenseCode: true,
          includeAnalytics: false
        }),
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Export failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `optimized-website-${websiteId}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    },
    onSuccess: () => {
      toast({
        title: "Export Complete",
        description: "Your optimized website has been downloaded.",
      });
    },
    onError: (error) => {
      toast({
        title: "Export Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (!websiteId) {
    return (
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>System Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600">No website selected. Start by analyzing a website URL.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isLoading || !config) {
    return (
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>System Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600">Loading configuration...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const handleConfigUpdate = (key: string, value: any) => {
    updateConfigMutation.mutate({ [key]: value });
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>System Configuration</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Auto Blogging Settings */}
          <div className="space-y-4">
            <h4 className="font-medium text-slate-900">Auto Blogging</h4>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-posting" className="text-sm text-slate-700">Enable Auto Posting</Label>
                <Switch
                  id="auto-posting"
                  checked={config.autoBloggingEnabled}
                  onCheckedChange={(checked) => handleConfigUpdate("autoBloggingEnabled", checked)}
                />
              </div>
              
              <div>
                <Label className="block text-sm text-slate-700 mb-1">Post Frequency</Label>
                <Select 
                  value={config.postFrequency} 
                  onValueChange={(value) => handleConfigUpdate("postFrequency", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1h">Every 1 hour</SelectItem>
                    <SelectItem value="2h">Every 2 hours</SelectItem>
                    <SelectItem value="6h">Every 6 hours</SelectItem>
                    <SelectItem value="24h">Daily</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="block text-sm text-slate-700 mb-1">Target Keywords</Label>
                <Textarea 
                  className="h-20 resize-none"
                  placeholder="AI, technology, innovation, healthcare..."
                  value={config.targetKeywords?.join(", ") || ""}
                  onChange={(e) => {
                    const keywords = e.target.value.split(",").map(k => k.trim()).filter(k => k);
                    handleConfigUpdate("targetKeywords", keywords);
                  }}
                />
              </div>
            </div>
          </div>

          {/* SEO Settings */}
          <div className="space-y-4">
            <h4 className="font-medium text-slate-900">SEO Optimization</h4>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm text-slate-700">Auto Meta Tags</Label>
                <Switch
                  checked={config.autoMetaTags}
                  onCheckedChange={(checked) => handleConfigUpdate("autoMetaTags", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-sm text-slate-700">Generate Sitemap</Label>
                <Switch
                  checked={config.generateSitemap}
                  onCheckedChange={(checked) => handleConfigUpdate("generateSitemap", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-sm text-slate-700">Internal Linking</Label>
                <Switch
                  checked={config.internalLinking}
                  onCheckedChange={(checked) => handleConfigUpdate("internalLinking", checked)}
                />
              </div>

              <div>
                <Label className="block text-sm text-slate-700 mb-1">Site Category</Label>
                <Select 
                  value={config.siteCategory} 
                  onValueChange={(value) => handleConfigUpdate("siteCategory", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Technology">Technology</SelectItem>
                    <SelectItem value="Business">Business</SelectItem>
                    <SelectItem value="Health">Health</SelectItem>
                    <SelectItem value="Lifestyle">Lifestyle</SelectItem>
                    <SelectItem value="Education">Education</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Export Settings */}
          <div className="space-y-4">
            <h4 className="font-medium text-slate-900">Export & Deployment</h4>
            
            <div className="space-y-3">
              <Button 
                className="w-full bg-emerald-600 hover:bg-emerald-700"
                onClick={() => exportMutation.mutate()}
                disabled={exportMutation.isPending}
              >
                <Download className="mr-2" size={16} />
                {exportMutation.isPending ? "Downloading..." : "Download Optimized Site"}
              </Button>

              <Button variant="outline" className="w-full">
                <Eye className="mr-2" size={16} />
                Preview Changes
              </Button>

              <div className="text-xs text-slate-500 space-y-1">
                <p>• Includes all optimized files</p>
                <p>• Ready for cPanel upload</p>
                <p>• Auto-posting system enabled</p>
                <p>• Configuration file included</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
