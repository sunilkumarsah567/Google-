import { Card, CardContent } from "@/components/ui/card";
import { Search, Gauge, Smartphone, DollarSign } from "lucide-react";

interface MetricsCardsProps {
  website?: any;
  stats?: any;
}

export default function MetricsCards({ website, stats }: MetricsCardsProps) {
  const metrics = [
    {
      title: "SEO Score",
      value: website?.seoScore || stats?.averageSeoScore || 0,
      icon: Search,
      color: "amber",
      bgColor: "bg-amber-100",
      iconColor: "text-amber-600",
      progressColor: "bg-amber-500"
    },
    {
      title: "Speed Score",
      value: website?.speedScore || stats?.averageSpeedScore || 0,
      icon: Gauge,
      color: "red",
      bgColor: "bg-red-100",
      iconColor: "text-red-600",
      progressColor: "bg-red-500"
    },
    {
      title: "Mobile Ready",
      value: website?.mobileScore || stats?.averageMobileScore || 0,
      icon: Smartphone,
      color: "emerald",
      bgColor: "bg-emerald-100",
      iconColor: "text-emerald-600",
      progressColor: "bg-emerald-500"
    },
    {
      title: "AdSense Ready",
      value: website?.adsenseReady || stats?.averageAdsenseReady || 0,
      icon: DollarSign,
      color: "red",
      bgColor: "bg-red-100",
      iconColor: "text-red-600",
      progressColor: "bg-red-500"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
      {metrics.map((metric) => (
        <Card key={metric.title} className="metrics-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">{metric.title}</p>
                <p className="text-3xl font-bold text-slate-900 mt-1">{metric.value}</p>
              </div>
              <div className={`w-12 h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                <metric.icon className={metric.iconColor} size={20} />
              </div>
            </div>
            <div className="mt-4">
              <div className="progress-bar">
                <div 
                  className={`progress-fill ${metric.progressColor}`}
                  style={{ width: `${metric.value}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
