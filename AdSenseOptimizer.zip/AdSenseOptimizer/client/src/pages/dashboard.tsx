import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import DashboardHeader from "@/components/dashboard-header";
import UrlInput from "@/components/url-input";
import MetricsCards from "@/components/metrics-cards";
import OptimizationProgress from "@/components/optimization-progress";
import AutoBloggingPanel from "@/components/auto-blogging-panel";
import ConfigurationPanel from "@/components/configuration-panel";
import ActivityLog from "@/components/activity-log";

export default function Dashboard() {
  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: websites } = useQuery({
    queryKey: ["/api/websites"],
  });

  const currentWebsite = websites?.[0]; // Use first website or most recent

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader />
        
        <main className="flex-1 overflow-y-auto p-6">
          {/* URL Input Section */}
          <UrlInput />
          
          {/* Status Overview Cards */}
          <MetricsCards website={currentWebsite} stats={stats} />
          
          {/* Two Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Optimization Progress */}
            <OptimizationProgress websiteId={currentWebsite?.id} />
            
            {/* Auto Blogging Status */}
            <AutoBloggingPanel websiteId={currentWebsite?.id} />
          </div>

          {/* Configuration Panel */}
          <ConfigurationPanel websiteId={currentWebsite?.id} />

          {/* Recent Activity Log */}
          <ActivityLog websiteId={currentWebsite?.id} />
        </main>
      </div>
    </div>
  );
}
