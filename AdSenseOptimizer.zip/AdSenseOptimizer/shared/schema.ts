import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const websites = pgTable("websites", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  title: text("title"),
  status: text("status").notNull().default("pending"), // pending, analyzing, optimizing, completed, error
  seoScore: integer("seo_score").default(0),
  speedScore: integer("speed_score").default(0),
  mobileScore: integer("mobile_score").default(0),
  adsenseReady: integer("adsense_ready").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const optimizationTasks = pgTable("optimization_tasks", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default("pending"), // pending, running, completed, failed
  progress: integer("progress").default(0),
  result: text("result"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  keywords: text("keywords").array(),
  category: text("category"),
  status: text("status").notNull().default("draft"), // draft, published, scheduled
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const configurations = pgTable("configurations", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull(),
  autoBloggingEnabled: boolean("auto_blogging_enabled").default(true),
  postFrequency: text("post_frequency").default("1h"), // 1h, 2h, 6h, 24h
  targetKeywords: text("target_keywords").array().default([]),
  siteCategory: text("site_category").default("Technology"),
  autoMetaTags: boolean("auto_meta_tags").default(true),
  generateSitemap: boolean("generate_sitemap").default(true),
  internalLinking: boolean("internal_linking").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id"),
  action: text("action").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // success, warning, error, info
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertWebsiteSchema = createInsertSchema(websites).pick({
  url: true,
  title: true,
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).pick({
  title: true,
  content: true,
  excerpt: true,
  keywords: true,
  category: true,
  status: true,
});

export const insertConfigurationSchema = createInsertSchema(configurations).omit({
  id: true,
  updatedAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).pick({
  websiteId: true,
  action: true,
  description: true,
  type: true,
  metadata: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Website = typeof websites.$inferSelect;
export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;
export type OptimizationTask = typeof optimizationTasks.$inferSelect;
export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type Configuration = typeof configurations.$inferSelect;
export type InsertConfiguration = z.infer<typeof insertConfigurationSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});
