<?php
/*
Plugin Name: Auto Backlinker
Plugin URI: http://wikilediablogs.liveblog365.com
Description: Automatically pings your WordPress site URLs to major ping services for backlinks and indexing.
Version: 1.0
Author: WikiLedia Team
*/

add_action('publish_post', 'ab_auto_ping_services');
add_action('publish_page', 'ab_auto_ping_services');

function ab_auto_ping_services($post_ID) {
    $ping_urls = array(
        "http://ping.feedburner.com",
        "http://ping.blogs.yandex.ru/RPC2",
        "http://rpc.pingomatic.com/",
        "http://blogsearch.google.com/ping/RPC2",
        "http://www.bing.com/ping?sitemap=",
        "http://www.feedlisting.com/",
        "http://blog.goo.ne.jp/XMLRPC",
        "http://ping.myblog.jp"
    );

    $post_url = get_permalink($post_ID);

    foreach ($ping_urls as $ping_url) {
        $target_url = (strpos($ping_url, 'sitemap') !== false) ? $ping_url . get_site_url() . '/sitemap.xml' : $ping_url;

        $response = wp_remote_post($target_url, array(
            'body' => array('url' => $post_url),
            'timeout' => 10,
            'headers' => array('Content-Type' => 'application/x-www-form-urlencoded')
        ));
    }
}
?>